CTRPF Plugins
==================================

NTR CFW plugin using [@Nanquitas](https://github.com/Nanquitas) NTR plugin framework.
This is a WIP, so feel free to report any issue.

### Plugin available for:
* Kirby Planet Robobot (Region Free)
* Kirby Triple Deluxe (EUR|USA)
* Mario Kart 7 (Should support all version with an update)
* Mario Luigi Dream Team Bros (EUR|USA -> 1.1)
* New Super Mario Bros 2 (EUR|USA)
* Pokemon X/Y (Region Free -> 1.5)
* Pokemon OR/AS (Region Free -> 1.4)
* Pokemon Sun/Moon (Region Free -> 1.2)
* Pokemon Super Mystery Dungeon (EUR|USA)

**Preview:**

![1](https://i.imgur.com/XQoo6sy.png)

For the list of the available cheat code you can check the thread on GBAtemp.

There is no online restriction, so if you got banned by whatever reason by using one of those plugins to take advantage in online games, then don't blame me, you'll deserve it.

### Usage

Plugin file goes to SD:\Plugin\GameTID\ *.plg
BMP (plugin backgrounds) goes in the same folder.

GameTID:

* Kirby Planet Robobot
	* Title ID Region Free
		0004000000183600

* Kirby Triple Deluxe
	* EUR
		000400000010C000
	* USA
		000400000010BF00

* Mario Kart 7
	* EUR
		0004000000030700
	* USA
		0004000000030800
	* JPN
		0004000000030600

* Mario & Luigi: Dream Team
	* EUR
		00040000000D9000
	* USA
		00040000000D5A00

* New Super Mario Bros 2
	* EUR
		000400000007AF00
	* USA
		000400000007AE00

* Pokemon XY
	* Y
		0004000000055E00
	* X
		0004000000055D00

* Pokemon ORAS
	* Alpha Sapphire
		000400000011C500
	* Ruby Omega
		000400000011C400

* Pokemon Sun/Moon
	* Sun
		0004000000164800
	* Moon
		0004000000175E00

* Pokemon Super Mystery Dungeon
	* EUR
		0004000000174400
	* USA
		0004000000174600

For information about feature like, the cheat searcher, game guide ect...
Please refer to this [PDF Guide](http://docdro.id/Sp0K2Xe).

### Credits
* [@Mega-Mew](https://github.com/Mega-Mew): Plugin & Cheats + Some other people (check Credits.txt for the list of the cheats that haven't be made by us.)
* Scotline: Cheats Codes/Plugins background picture.
* NotFair: Cheats Codes/useful advices.
* [@Nanquitas](https://github.com/Nanquitas): for his plugin framework & his help !

Plugin source codes not yet available, need some clean up before.




